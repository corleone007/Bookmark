//console.log("this is a test")
const express = require("express")
const bodyParser= require('body-parser')
const app = express()
const MongoClient = require('mongodb').MongoClient
app.set('view engine', 'ejs')
var db

MongoClient.connect('mongodb://admin:Password123@ds147069.mlab.com:47069/bookmark-shortcuts', (err, database) => {
  if (err) return console.log(err)
  db = database
  app.listen(3000, () => {
    console.log('listening on 3000')
  })
})

var __dirname = 'C:/Users/shama/Documents/Learning Documents/Node/zellwk/ui'
/*app.listen(3000, function(){
	console.log("listening on 3000")
})*/
app.get('/', (req, res) => {
  db.collection('quotes').find().toArray((err, result) => {
    if (err) return console.log(err)
    // renders index.ejs
    res.render('index.ejs', {quotes: result})
  })
})

app.use(bodyParser.urlencoded({extended: true}))

app.post('/quotes', (req, res) => {
  db.collection('quotes').save(req.body, (err, result) => {
    if (err) return console.log(err)

    console.log('saved to database')
    res.redirect('/')
  })
})


// Note: request and response are usually written as req and res respectively.